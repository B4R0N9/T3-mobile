package com.example.tugas3ku





import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNama     = findViewById<EditText>(R.id.etNama)
        val rgKelamin  = findViewById<RadioGroup>(R.id.rgKelamin)
        val cbMembaca  = findViewById<CheckBox>(R.id.cbMembaca)
        val cbCoding   = findViewById<CheckBox>(R.id.cbCoding)
        val cbOlahraga = findViewById<CheckBox>(R.id.cbOlahraga)
        val btnTampilkan = findViewById<Button>(R.id.btnTampilkan)
        val tvHasil    = findViewById<TextView>(R.id.tvHasil)

        btnTampilkan.setOnClickListener {
            val nama = etNama.text.toString().trim()

            if (nama.isEmpty()) {
                etNama.error = "Nama tidak boleh kosong"
                Toast.makeText(this, "Harap isi nama terlebih dahulu!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val genderId = rgKelamin.checkedRadioButtonId
            val gender = if (genderId != -1)
                findViewById<RadioButton>(genderId).text.toString()
            else
                "Belum dipilih"

            val hobiList = mutableListOf<String>()
            if (cbMembaca.isChecked)  hobiList.add("Membaca")
            if (cbCoding.isChecked)   hobiList.add("Coding")
            if (cbOlahraga.isChecked) hobiList.add("Olahraga")

            val hobiText = if (hobiList.isEmpty()) "Tidak ada" else hobiList.joinToString(", ")

            tvHasil.text = "Nama    : $nama\nKelamin : $gender\nHobi    : $hobiText"
            tvHasil.setTextColor(android.graphics.Color.parseColor("#E8EAF6"))
        }
    }
}